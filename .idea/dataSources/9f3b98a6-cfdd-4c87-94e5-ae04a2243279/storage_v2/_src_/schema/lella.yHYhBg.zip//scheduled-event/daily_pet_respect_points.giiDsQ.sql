create definer = root@localhost event daily_pet_respect_points on schedule
    every '24' HOUR
        starts '2015-02-09 22:00:00'
    enable
    do
    update users_stats set daily_pet_respect_points = 5 where daily_pet_respect_points = 0;

