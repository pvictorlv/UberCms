create
    definer = root@localhost procedure dofastfoodlogin(IN sso_ticket varchar(50)) no sql
BEGIN
        SELECT users.username, users.id, users.credits, users.look, users.gender, user_fastfood.fastGames, user_fastfood.parachute, user_fastfood.missile, user_fastfood.shield, user_fastfood.ff_points FROM users
        LEFT JOIN user_fastfood ON (user_fastfood.userid =users.id)
        RIGHT JOIN user_auth_food ON (user_auth_food.user_id = users.id)
        WHERE user_auth_food.auth_ticket=sso_ticket;
END;

